EMAAN BIRTHDAY WEBSITE
=======================

Birthday: 15 September
Name: Emaan
Song: Meri Zindagi Hai Tu (official YouTube embed)

FILES:
- index.html
- images/emaan-1.jpeg ... emaan-5.jpeg

HOW TO PUBLISH WITH GITHUB PAGES:
1. Create/open a GitHub repository.
2. Upload index.html and the entire images folder.
3. Commit the files.
4. Open Settings > Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Select the main branch and the / (root) folder, then Save.
7. GitHub will give you a public website address.
8. Send that public https://... address on WhatsApp.

IMPORTANT:
The song is embedded from YouTube instead of copying the copyrighted audio file.
If you want a local audio file, replace the YouTube section only with audio you have permission to use.
